# CHANGELOG — TaskPulse

Log **every** change here so anyone (especially Piyush) can see the delta at a glance.
**Newest entry on top.** One entry per change/branch. See `HOW_TO_MAKE_CHANGES.md` for the full workflow.

Copy this template for each new change:

```
## [YYYY-MM-DD] <short title>
- Branch: change/<short-name>   (fork: github.com/gauravthapar81-ai/taskpulse)
- Who: <name>
- What: <plain-language description of what changed>
- Why: <the problem it solves / goal>
- Files touched: <list, or "see PR diff">
- Tested: tsc <pass/fail> · npm test <pass/fail> · deployed-to-fork-Pages <yes/no> · crossOriginIsolated=true <yes/no> · devices <phone/laptop>
- Status: <testing on my fork | PR opened to DocEmm19/taskpulse #<n> | merged to production>
- Notes / issues for Piyush: <anything odd, errors, screenshots, or "none">
```

---

## [2026-08-19] Fix Due Date/Time picker on web + attachments during New Task creation
- Branch: change/new-task-date-and-attachments   (fork: github.com/gauravthapar81-ai/taskpulse)
- Who: Gaurav (with AI assistant)
- What: (1) Due Date field on New Task/Edit now opens a working picker on web (was silently doing nothing) and supports picking a time as well as a date. (2) New Task screen now has an Attachments section — Gallery image, PDF, Record Audio, and Video File can all be added before the task is saved; they're written to the task once Create Task succeeds.
- Why: testing found the Due Date field non-responsive on the deployed web build, and attachments were only available after a task was already saved, per the two issues reported during testing.
- Files touched: app/src/components/DateTimeField.tsx (added a web-specific render branch; android/ios logic untouched), app/src/components/AttachmentsSection.tsx (refactored to source picking/recording from a new shared hook — same behavior, no duplicate logic), app/src/hooks/useAttachmentCapture.ts (new — shared capture mechanics used by both the edit screen and New Task), app/src/components/PendingAttachmentsSection.tsx (new — New Task's attachments UI, stages files in memory until Create Task succeeds), app/src/screens/NewEditTaskScreen.tsx (Due Date now mode="datetime"; wires in PendingAttachmentsSection and saves staged files via addAttachment right after the task is created).
- Tested: tsc pass · npm test pass (72/72, same count as baseline) · build:web pass (`npm run build:web`) · devices: <fill in after your own click-through — see acceptance test below>
- Status: testing on my fork
- Notes / issues for Piyush: attachments picked during New Task are held in memory (not yet in the database) until Create Task succeeds — if the browser tab is closed before saving, those files are lost, same as any other unsaved form field on this screen. No changes made to app/src/lib/sync/**, app/scripts/**, or schema_and_setup.sql.

---

## [2026-08-17] v1 baseline (starting point — do not edit, for reference)
- Branch: main
- Who: Piyush (build) — handed to Gaurav
- What: TaskPulse v1 live: web-only Expo→GitHub Pages, offline-first local DB, two-way Supabase sync (push+pull+realtime, last-write-wins), invite-only shared workspace, PWA, web voice recording + best-effort web reminders.
- Why: production handoff for Gaurav + Abhay to use and test.
- Files touched: (initial bundle)
- Tested: tsc pass · npm test pass (72) · build:web pass · crossOriginIsolated=true verified live · devices: desktop+mobile browser
- Status: merged to production (https://docemm19.github.io/taskpulse/)
- Notes / issues for Piyush: known v1 limitations — Activity/Reassignment history is per-device (tasks + their data sync); sync/auth need a Supabase project + 2 repo secrets to activate (see SETUP.md).
```
```
