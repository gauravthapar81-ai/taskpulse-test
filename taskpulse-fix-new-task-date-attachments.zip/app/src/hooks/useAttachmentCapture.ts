import { useState } from 'react';
import { Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import { AudioModule, RecordingPresets, setAudioModeAsync, useAudioRecorder, useAudioRecorderState } from 'expo-audio';
import { persistLocalFile } from '../lib/localFiles';
import { startWebRecording, webRecordingSupported, WebRecordingHandle } from '../lib/webAudioRecorder';
import { canUseCamera, canRecordAudio, isWeb } from '../lib/platform';
import { AttachmentType } from '../types/models';

/** Shape of a captured file before it's associated with any task — the same
 * fields AddAttachmentInput needs, minus taskId. */
export interface CapturedFile {
  fileType: AttachmentType;
  fileName: string;
  localPath: string;
  fileSizeBytes?: number | null;
  mimeType?: string | null;
  durationSeconds?: number | null;
}

/**
 * Shared attachment-capture mechanics: picking a photo/PDF/video or
 * recording audio, ending with a locally-persisted file ready to be saved.
 * Used by both AttachmentsSection (saves each capture immediately against an
 * existing task) and the New Task screen's pending-attachments flow (holds
 * captures in memory until the task is created). How a file is picked,
 * recorded, or stored lives here once — callers only decide when to persist
 * the result via addAttachment.
 */
export function useAttachmentCapture() {
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const recorderState = useAudioRecorderState(recorder, 500);

  const [webRecording, setWebRecording] = useState<WebRecordingHandle | null>(null);
  const [isWebRecording, setIsWebRecording] = useState(false);

  async function pickImage(fromCamera: boolean): Promise<CapturedFile[]> {
    const perm = fromCamera ? await ImagePicker.requestCameraPermissionsAsync() : await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) {
      Alert.alert('Permission needed');
      return [];
    }
    const result = fromCamera
      ? await ImagePicker.launchCameraAsync({ quality: 0.8 })
      : await ImagePicker.launchImageLibraryAsync({ quality: 0.8, allowsMultipleSelection: true, mediaTypes: ['images'] });
    if (result.canceled) return [];
    const out: CapturedFile[] = [];
    for (const asset of result.assets) {
      const localPath = await persistLocalFile(asset.uri, 'jpg');
      out.push({ fileType: 'image', fileName: asset.fileName ?? `photo_${Date.now()}.jpg`, localPath, fileSizeBytes: asset.fileSize ?? null, mimeType: 'image/jpeg' });
    }
    return out;
  }

  async function pickPdf(): Promise<CapturedFile[]> {
    const result = await DocumentPicker.getDocumentAsync({ type: 'application/pdf', multiple: true, copyToCacheDirectory: true });
    if (result.canceled) return [];
    const out: CapturedFile[] = [];
    for (const asset of result.assets) {
      const localPath = await persistLocalFile(asset.uri, 'pdf');
      out.push({ fileType: 'pdf', fileName: asset.name, localPath, fileSizeBytes: asset.size ?? null, mimeType: 'application/pdf' });
    }
    return out;
  }

  async function pickVideo(): Promise<CapturedFile | null> {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) {
      Alert.alert('Permission needed');
      return null;
    }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['videos'], quality: 0.7 });
    if (result.canceled) return null;
    const asset = result.assets[0];
    const localPath = await persistLocalFile(asset.uri, 'mp4');
    return {
      fileType: 'video',
      fileName: asset.fileName ?? `video_${Date.now()}.mp4`,
      localPath,
      fileSizeBytes: asset.fileSize ?? null,
      durationSeconds: asset.duration ? Math.round(asset.duration / 1000) : null,
      mimeType: 'video/mp4',
    };
  }

  async function recordVideo(): Promise<CapturedFile | null> {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      Alert.alert('Permission needed');
      return null;
    }
    const result = await ImagePicker.launchCameraAsync({ mediaTypes: ['videos'], quality: 0.7 });
    if (result.canceled) return null;
    const asset = result.assets[0];
    const localPath = await persistLocalFile(asset.uri, 'mp4');
    return {
      fileType: 'video',
      fileName: `video_${Date.now()}.mp4`,
      localPath,
      durationSeconds: asset.duration ? Math.round(asset.duration / 1000) : null,
      mimeType: 'video/mp4',
    };
  }

  async function startRecording() {
    const perm = await AudioModule.requestRecordingPermissionsAsync();
    if (!perm.granted) {
      Alert.alert('Microphone permission needed');
      return;
    }
    await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true });
    await recorder.prepareToRecordAsync();
    recorder.record();
  }

  async function stopRecording(): Promise<CapturedFile | null> {
    const seconds = Math.round((recorderState.durationMillis ?? 0) / 1000);
    await recorder.stop();
    const uri = recorder.uri;
    if (!uri) return null;
    const localPath = await persistLocalFile(uri, 'm4a');
    return { fileType: 'audio', fileName: `voice_note_${Date.now()}.m4a`, localPath, durationSeconds: seconds, mimeType: 'audio/m4a' };
  }

  async function startWebRecordingFlow() {
    try {
      const handle = await startWebRecording();
      setWebRecording(handle);
      setIsWebRecording(true);
    } catch (err) {
      Alert.alert('Microphone permission needed', err instanceof Error ? err.message : undefined);
    }
  }

  async function stopWebRecordingFlow(): Promise<CapturedFile | null> {
    if (!webRecording) return null;
    setIsWebRecording(false);
    setWebRecording(null);
    try {
      const { uri, mimeType, fileName } = await webRecording.stop();
      const extension = mimeType.includes('mp4') ? 'mp4' : mimeType.includes('ogg') ? 'ogg' : 'webm';
      const localPath = await persistLocalFile(uri, extension);
      return { fileType: 'audio', fileName, localPath, mimeType };
    } catch (err) {
      Alert.alert('Recording failed', err instanceof Error ? err.message : undefined);
      return null;
    }
  }

  return {
    canUseCamera,
    canRecordAudio,
    isWeb,
    webRecordingSupported,
    isRecording: recorderState.isRecording,
    recordSeconds: Math.round((recorderState.durationMillis ?? 0) / 1000),
    isWebRecording,
    pickImage,
    pickPdf,
    pickVideo,
    recordVideo,
    startRecording,
    stopRecording,
    startWebRecordingFlow,
    stopWebRecordingFlow,
  };
}
