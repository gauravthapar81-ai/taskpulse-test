import React, { useEffect, useState } from 'react';
import { Alert, Image, Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAudioPlayer, useAudioPlayerStatus } from 'expo-audio';
import { useVideoPlayer, VideoView } from 'expo-video';
import * as Sharing from 'expo-sharing';
import { Attachment, AttachmentType } from '../types/models';
import { addAttachment, deleteAttachment, renameAttachment } from '../db/repositories/attachments';
import { useAttachmentCapture } from '../hooks/useAttachmentCapture';
import { colors, radius, spacing, typography } from '../theme/theme';
import { SectionCard } from './Common';

interface Props {
  taskId: string;
  attachments: Attachment[];
}

const ICONS: Record<AttachmentType, any> = { image: 'image-outline', pdf: 'document-text-outline', audio: 'mic-outline', video: 'videocam-outline' };

async function shareFile(att: Attachment) {
  if (!att.local_path) return;
  const available = await Sharing.isAvailableAsync();
  if (!available) return Alert.alert('Sharing not available on this device');
  await Sharing.shareAsync(att.local_path);
}

export function AttachmentsSection({ taskId, attachments }: Props) {
  const [preview, setPreview] = useState<Attachment | null>(null);
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameText, setRenameText] = useState('');
  const [activeAudioId, setActiveAudioId] = useState<string | null>(null);
  const [activeAudioUri, setActiveAudioUri] = useState<string | null>(null);

  // ---- Capture (picking/recording) — shared with the New Task screen's
  // pending-attachments flow via useAttachmentCapture. Here, every capture
  // is persisted to this existing task immediately, exactly as before.
  const capture = useAttachmentCapture();

  async function pickImage(fromCamera: boolean) {
    const files = await capture.pickImage(fromCamera);
    for (const f of files) await addAttachment({ taskId, ...f });
  }

  async function pickPdf() {
    const files = await capture.pickPdf();
    for (const f of files) await addAttachment({ taskId, ...f });
  }

  async function pickVideo() {
    const f = await capture.pickVideo();
    if (f) await addAttachment({ taskId, ...f });
  }

  async function recordVideo() {
    const f = await capture.recordVideo();
    if (f) await addAttachment({ taskId, ...f });
  }

  async function stopRecording() {
    const f = await capture.stopRecording();
    if (f) await addAttachment({ taskId, ...f });
  }

  async function stopWebRecordingFlow() {
    const f = await capture.stopWebRecordingFlow();
    if (f) await addAttachment({ taskId, ...f });
  }

  // ---- Playback (expo-audio, hook-based: one shared player, swap source) ----
  const player = useAudioPlayer(activeAudioUri ?? undefined);
  const playerStatus = useAudioPlayerStatus(player);

  useEffect(() => {
    if (activeAudioUri) player.play();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeAudioUri]);

  useEffect(() => {
    if (playerStatus.didJustFinish) setActiveAudioId(null);
  }, [playerStatus.didJustFinish]);

  function togglePlay(att: Attachment) {
    if (!att.local_path) return;
    if (activeAudioId === att.id) {
      if (playerStatus.playing) player.pause();
      else player.play();
      return;
    }
    setActiveAudioId(att.id);
    setActiveAudioUri(att.local_path);
  }

  function confirmDelete(att: Attachment) {
    Alert.alert('Delete attachment', `Delete "${att.file_name}"?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => deleteAttachment(att.id) },
    ]);
  }

  function submitRename() {
    if (renamingId && renameText.trim()) renameAttachment(renamingId, renameText.trim());
    setRenamingId(null);
  }

  const isRecording = capture.isRecording;
  const recordSeconds = capture.recordSeconds;

  return (
    <SectionCard title="Attachments" icon="attach-outline">
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.actionsRow}>
        {capture.canUseCamera && <ActionButton icon="camera-outline" label="Photo" onPress={() => pickImage(true)} />}
        <ActionButton icon="images-outline" label="Gallery" onPress={() => pickImage(false)} />
        <ActionButton icon="document-attach-outline" label="PDF" onPress={pickPdf} />
        {capture.canRecordAudio && (
          <ActionButton icon={isRecording ? 'stop-circle' : 'mic-outline'} label={isRecording ? `Stop (${recordSeconds}s)` : 'Record'} onPress={isRecording ? stopRecording : capture.startRecording} danger={isRecording} />
        )}
        {capture.isWeb && capture.webRecordingSupported && (
          <ActionButton
            icon={capture.isWebRecording ? 'stop-circle' : 'mic-outline'}
            label={capture.isWebRecording ? 'Stop' : 'Record Audio'}
            onPress={capture.isWebRecording ? stopWebRecordingFlow : capture.startWebRecordingFlow}
            danger={capture.isWebRecording}
          />
        )}
        {capture.canUseCamera && <ActionButton icon="videocam-outline" label="Record Video" onPress={recordVideo} />}
        <ActionButton icon="film-outline" label="Video File" onPress={pickVideo} />
      </ScrollView>

      {(!capture.canUseCamera || !capture.canRecordAudio) && <Text style={styles.empty}>available in the phone app</Text>}

      {attachments.length === 0 ? (
        <Text style={styles.empty}>No attachments yet. Add a photo, PDF, voice note, or video above.</Text>
      ) : (
        <View style={{ gap: spacing.sm }}>
          {attachments.map((att) => {
            const isPlayingThis = activeAudioId === att.id && playerStatus.playing;
            return (
              <View key={att.id} style={styles.attachmentRow}>
                <Pressable
                  style={styles.attachmentMain}
                  onPress={() => {
                    if (att.file_type === 'image' || att.file_type === 'video') setPreview(att);
                    else if (att.file_type === 'audio') togglePlay(att);
                    else shareFile(att);
                  }}
                >
                  <Ionicons name={att.file_type === 'audio' && isPlayingThis ? 'pause-circle' : ICONS[att.file_type]} size={22} color={colors.brand} />
                  {renamingId === att.id ? (
                    <TextInput value={renameText} onChangeText={setRenameText} onSubmitEditing={submitRename} onBlur={submitRename} autoFocus style={styles.renameInput} />
                  ) : (
                    <View style={{ flex: 1 }}>
                      <Text style={styles.attachmentName} numberOfLines={1}>{att.file_name}</Text>
                      <Text style={styles.attachmentMeta}>
                        {att.duration_seconds ? `${att.duration_seconds}s · ` : ''}
                        {att.sync_status === 'synced' ? 'Synced' : 'Stored on device'}
                      </Text>
                    </View>
                  )}
                </Pressable>
                <View style={styles.attachmentActions}>
                  <Ionicons name="share-outline" size={18} color={colors.textSecondary} onPress={() => shareFile(att)} />
                  <Ionicons
                    name="pencil-outline"
                    size={18}
                    color={colors.textSecondary}
                    onPress={() => {
                      setRenamingId(att.id);
                      setRenameText(att.file_name);
                    }}
                  />
                  <Ionicons name="trash-outline" size={18} color={colors.danger} onPress={() => confirmDelete(att)} />
                </View>
              </View>
            );
          })}
        </View>
      )}

      <Modal visible={Boolean(preview)} transparent animationType="fade" onRequestClose={() => setPreview(null)}>
        <Pressable style={styles.modalBackdrop} onPress={() => setPreview(null)}>
          {preview?.file_type === 'image' && preview.local_path && (
            <Image source={{ uri: preview.local_path }} style={styles.previewImage} resizeMode="contain" />
          )}
          {preview?.file_type === 'video' && preview.local_path && <VideoPreview uri={preview.local_path} />}
        </Pressable>
      </Modal>
    </SectionCard>
  );
}

/** Mounted only while the preview modal is open, so the video player hook
 * (expo-video) is created fresh for whichever attachment was tapped. */
function VideoPreview({ uri }: { uri: string }) {
  const player = useVideoPlayer(uri, (p) => {
    p.play();
  });
  return <VideoView player={player} style={styles.previewVideo} nativeControls contentFit="contain" />;
}

function ActionButton({ icon, label, onPress, danger }: { icon: any; label: string; onPress: () => void; danger?: boolean }) {
  return (
    <Pressable style={styles.actionButton} onPress={onPress}>
      <Ionicons name={icon} size={20} color={danger ? colors.danger : colors.brand} />
      <Text style={[styles.actionLabel, danger && { color: colors.danger }]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  actionsRow: { gap: spacing.sm, paddingBottom: spacing.md },
  actionButton: { alignItems: 'center', gap: 4, backgroundColor: colors.brandSoft, padding: spacing.sm, borderRadius: radius.md, width: 76 },
  actionLabel: { ...typography.tiny, color: colors.brand, textAlign: 'center' },
  empty: { ...typography.caption, color: colors.textMuted, fontStyle: 'italic', paddingVertical: spacing.sm },
  attachmentRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: spacing.xs, borderBottomWidth: 1, borderBottomColor: colors.border },
  attachmentMain: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, flex: 1 },
  attachmentName: { ...typography.body, color: colors.textPrimary },
  attachmentMeta: { ...typography.tiny, color: colors.textMuted },
  attachmentActions: { flexDirection: 'row', gap: spacing.sm, paddingLeft: spacing.sm },
  renameInput: { ...typography.body, color: colors.textPrimary, flex: 1, borderBottomWidth: 1, borderBottomColor: colors.brand },
  modalBackdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.9)', alignItems: 'center', justifyContent: 'center' },
  previewImage: { width: '100%', height: '80%' },
  previewVideo: { width: '100%', height: '50%' },
});
