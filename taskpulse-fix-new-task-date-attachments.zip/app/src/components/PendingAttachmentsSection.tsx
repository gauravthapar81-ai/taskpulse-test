import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AttachmentType } from '../types/models';
import { CapturedFile, useAttachmentCapture } from '../hooks/useAttachmentCapture';
import { colors, radius, spacing, typography } from '../theme/theme';
import { SectionCard } from './Common';

interface Props {
  files: CapturedFile[];
  onChange: (files: CapturedFile[]) => void;
}

const ICONS: Record<AttachmentType, any> = { image: 'image-outline', pdf: 'document-text-outline', audio: 'mic-outline', video: 'videocam-outline' };

/**
 * Attachments UI for the New Task screen — same capture mechanics as
 * AttachmentsSection (via the shared useAttachmentCapture hook), but nothing
 * is written to the database yet: captured files are held here in memory
 * and handed back to the caller (NewEditTaskScreen) via onChange. The caller
 * saves them with addAttachment once the task actually exists, right after
 * Create Task succeeds — see NewEditTaskScreen.handleSave.
 */
export function PendingAttachmentsSection({ files, onChange }: Props) {
  const capture = useAttachmentCapture();

  function add(newFiles: CapturedFile[]) {
    if (newFiles.length) onChange([...files, ...newFiles]);
  }

  function removeAt(index: number) {
    onChange(files.filter((_, i) => i !== index));
  }

  async function onRecordPress() {
    if (capture.isRecording) {
      const f = await capture.stopRecording();
      if (f) add([f]);
    } else {
      await capture.startRecording();
    }
  }

  async function onWebRecordPress() {
    if (capture.isWebRecording) {
      const f = await capture.stopWebRecordingFlow();
      if (f) add([f]);
    } else {
      await capture.startWebRecordingFlow();
    }
  }

  return (
    <SectionCard title="Attachments" icon="attach-outline">
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.actionsRow}>
        {capture.canUseCamera && <ActionButton icon="camera-outline" label="Photo" onPress={async () => add(await capture.pickImage(true))} />}
        <ActionButton icon="images-outline" label="Gallery" onPress={async () => add(await capture.pickImage(false))} />
        <ActionButton icon="document-attach-outline" label="PDF" onPress={async () => add(await capture.pickPdf())} />
        {capture.canRecordAudio && (
          <ActionButton
            icon={capture.isRecording ? 'stop-circle' : 'mic-outline'}
            label={capture.isRecording ? `Stop (${capture.recordSeconds}s)` : 'Record'}
            onPress={onRecordPress}
            danger={capture.isRecording}
          />
        )}
        {capture.isWeb && capture.webRecordingSupported && (
          <ActionButton
            icon={capture.isWebRecording ? 'stop-circle' : 'mic-outline'}
            label={capture.isWebRecording ? 'Stop' : 'Record Audio'}
            onPress={onWebRecordPress}
            danger={capture.isWebRecording}
          />
        )}
        {capture.canUseCamera && (
          <ActionButton
            icon="videocam-outline"
            label="Record Video"
            onPress={async () => {
              const f = await capture.recordVideo();
              if (f) add([f]);
            }}
          />
        )}
        <ActionButton
          icon="film-outline"
          label="Video File"
          onPress={async () => {
            const f = await capture.pickVideo();
            if (f) add([f]);
          }}
        />
      </ScrollView>

      {!capture.canUseCamera && !capture.canRecordAudio && !(capture.isWeb && capture.webRecordingSupported) && (
        <Text style={styles.empty}>available in the phone app</Text>
      )}

      {files.length === 0 ? (
        <Text style={styles.empty}>No attachments yet. Add a photo, PDF, voice note, or video above — they'll be saved with the task.</Text>
      ) : (
        <View style={{ gap: spacing.sm }}>
          {files.map((f, i) => (
            <View key={`${f.fileName}-${i}`} style={styles.row}>
              <Ionicons name={ICONS[f.fileType]} size={20} color={colors.brand} />
              <Text style={styles.name} numberOfLines={1}>{f.fileName}</Text>
              <Ionicons name="close-circle" size={20} color={colors.textMuted} onPress={() => removeAt(i)} />
            </View>
          ))}
        </View>
      )}
    </SectionCard>
  );
}

function ActionButton({ icon, label, onPress, danger }: { icon: any; label: string; onPress: () => void; danger?: boolean }) {
  return (
    <Pressable style={styles.actionButton} onPress={onPress}>
      <Ionicons name={icon} size={20} color={danger ? colors.danger : colors.brand} />
      <Text style={[styles.actionLabel, danger && { color: colors.danger }]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  actionsRow: { gap: spacing.sm, paddingBottom: spacing.md },
  actionButton: { alignItems: 'center', gap: 4, backgroundColor: colors.brandSoft, padding: spacing.sm, borderRadius: radius.md, width: 76 },
  actionLabel: { ...typography.tiny, color: colors.brand, textAlign: 'center' },
  empty: { ...typography.caption, color: colors.textMuted, fontStyle: 'italic', paddingVertical: spacing.sm },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingVertical: spacing.xs, borderBottomWidth: 1, borderBottomColor: colors.border },
  name: { ...typography.body, color: colors.textPrimary, flex: 1 },
});
