import React, { useState } from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Ionicons } from '@expo/vector-icons';
import { format } from 'date-fns';
import { colors, radius, spacing, typography } from '../theme/theme';
import { isWeb } from '../lib/platform';

interface Props {
  label: string;
  value: Date | null;
  onChange: (d: Date | null) => void;
  mode?: 'date' | 'time' | 'datetime';
  clearable?: boolean;
  placeholder?: string;
}

/** Cross-platform date/time picker. Android shows its native dialog on demand;
 * iOS shows an inline compact picker below the field once tapped — both close
 * themselves after picking so this works the same from either OS. */
export function DateTimeField({ label, value, onChange, mode = 'date', clearable = true, placeholder = 'Not set' }: Props) {
  const [showIOSPicker, setShowIOSPicker] = useState(false);

  const displayText = value
    ? mode === 'date'
      ? format(value, 'dd-MMM-yyyy')
      : format(value, 'dd-MMM-yyyy, h:mm a')
    : placeholder;

  function openPicker() {
    if (Platform.OS === 'android') {
      const DateTimePickerAndroid = require('@react-native-community/datetimepicker').DateTimePickerAndroid;
      DateTimePickerAndroid.open({
        value: value ?? new Date(),
        mode: 'date',
        onChange: (_e: any, selectedDate?: Date) => {
          if (!selectedDate) return;
          if (mode === 'datetime') {
            DateTimePickerAndroid.open({
              value: selectedDate,
              mode: 'time',
              onChange: (_e2: any, time?: Date) => {
                if (!time) return onChange(selectedDate);
                const combined = new Date(selectedDate);
                combined.setHours(time.getHours(), time.getMinutes());
                onChange(combined);
              },
            });
          } else {
            onChange(selectedDate);
          }
        },
      });
    } else {
      setShowIOSPicker(true);
    }
  }

  // Web has no implementation of @react-native-community/datetimepicker —
  // openPicker()'s non-android branch above sets showIOSPicker, but the
  // inline picker below only ever renders when Platform.OS === 'ios', so on
  // web nothing appeared and the field looked unresponsive. Render the
  // browser's own native date/time input instead — it has a working picker
  // built in and needs no extra dependency. Native (android/ios) rendering
  // below is unchanged.
  if (isWeb) {
    const inputType = mode === 'date' ? 'date' : mode === 'time' ? 'time' : 'datetime-local';

    const toInputValue = (d: Date | null): string => {
      if (!d) return '';
      const pad = (n: number) => String(n).padStart(2, '0');
      const y = d.getFullYear();
      const mo = pad(d.getMonth() + 1);
      const da = pad(d.getDate());
      if (mode === 'date') return `${y}-${mo}-${da}`;
      const h = pad(d.getHours());
      const mi = pad(d.getMinutes());
      if (mode === 'time') return `${h}:${mi}`;
      return `${y}-${mo}-${da}T${h}:${mi}`;
    };

    const fromInputValue = (raw: string): Date | null => {
      if (!raw) return null;
      if (mode === 'time') {
        const base = value ? new Date(value) : new Date();
        const [h, mi] = raw.split(':').map(Number);
        base.setHours(h, mi, 0, 0);
        return base;
      }
      const parsed = new Date(raw);
      return isNaN(parsed.getTime()) ? null : parsed;
    };

    return (
      <View style={styles.field}>
        <Text style={styles.label}>{label}</Text>
        <View style={styles.row}>
          <Ionicons name="calendar-outline" size={18} color={colors.textSecondary} />
          {/* @ts-ignore — plain DOM input; valid under react-native-web on this target */}
          <input
            type={inputType}
            value={toInputValue(value)}
            onChange={(e: any) => onChange(fromInputValue(e.target.value))}
            style={{ flex: 1, border: 'none', outline: 'none', background: 'transparent', fontSize: 15, color: colors.textPrimary, fontFamily: 'inherit', padding: 0 }}
          />
          {clearable && value ? (
            <Ionicons name="close-circle" size={18} color={colors.textMuted} onPress={() => onChange(null)} />
          ) : null}
        </View>
      </View>
    );
  }

  return (
    <View style={styles.field}>
      <Text style={styles.label}>{label}</Text>
      <Pressable style={styles.row} onPress={openPicker}>
        <Ionicons name="calendar-outline" size={18} color={colors.textSecondary} />
        <Text style={[styles.value, !value && { color: colors.textMuted }]}>{displayText}</Text>
        {clearable && value ? (
          <Ionicons name="close-circle" size={18} color={colors.textMuted} onPress={() => onChange(null)} />
        ) : null}
      </Pressable>
      {Platform.OS === 'ios' && showIOSPicker && (
        <View style={styles.iosPickerWrap}>
          <DateTimePicker
            value={value ?? new Date()}
            mode={mode === 'datetime' ? 'datetime' : mode}
            display="spinner"
            onChange={(_e, d) => {
              if (d) onChange(d);
            }}
          />
          <Pressable style={styles.doneBtn} onPress={() => setShowIOSPicker(false)}>
            <Text style={styles.doneText}>Done</Text>
          </Pressable>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  field: { marginBottom: spacing.lg },
  label: { ...typography.captionMedium, color: colors.textSecondary, marginBottom: spacing.xs },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    backgroundColor: colors.surface,
  },
  value: { ...typography.body, color: colors.textPrimary, flex: 1 },
  iosPickerWrap: { backgroundColor: colors.surface, borderRadius: radius.md, marginTop: spacing.xs },
  doneBtn: { alignSelf: 'flex-end', padding: spacing.sm },
  doneText: { ...typography.captionMedium, color: colors.brand },
});
