import { getDb } from './database';
import { newId } from '../lib/uuid';
import { notifyTablesChanged } from './events';
import { ActivityEventType, SyncOperation } from '../types/models';
import { getDeviceId } from '../store/sessionStore';

export function nowIso(): string {
  return new Date().toISOString();
}

/** Appends an immutable row to task_activity. Never call UPDATE on this table —
 * per ARCHITECTURE.md §5.2/#40, activity history is append-only. */
export async function logActivity(taskId: string, eventType: ActivityEventType, description: string) {
  const db = await getDb();
  await db.runAsync(
    `INSERT INTO task_activity (id, task_id, event_type, description, actor_device_id, created_at)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [newId(), taskId, eventType, description, getDeviceId(), nowIso()]
  );
  notifyTablesChanged('task_activity');
}

/** Queues a row for the (stubbed) Sync Engine to push to Supabase later. Every
 * write to a syncable table should call this — see ARCHITECTURE.md §4.1. */
export async function enqueueSync(entityType: string, entityId: string, operation: SyncOperation, payload?: unknown) {
  const db = await getDb();
  await db.runAsync(
    `INSERT INTO sync_queue (id, entity_type, entity_id, operation, payload, retry_count, status, created_at)
     VALUES (?, ?, ?, ?, ?, 0, 'queued', ?)`,
    [newId(), entityType, entityId, operation, payload ? JSON.stringify(payload) : null, nowIso()]
  );
  notifyTablesChanged('sync_queue');
}
