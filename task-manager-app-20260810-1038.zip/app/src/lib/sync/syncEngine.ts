import NetInfo from '@react-native-community/netinfo';
import { readFileBytes } from '../localFiles';
import { getDb } from '../../db/database';
import { getSupabase, isSupabaseConfigured, ATTACHMENTS_BUCKET } from './supabaseClient';
import { getCurrentUserId } from '../../store/sessionStore';
import { notifyTablesChanged } from '../../db/events';
import { SyncQueueItem } from '../../types/models';

// ----------------------------------------------------------------------------
// Sync Engine — implements ARCHITECTURE.md §4. This is the ONLY module in the
// app that talks to Supabase. Every screen reads/writes local SQLite only; this
// engine drains `sync_queue` in the background and is safe to call repeatedly.
//
// Direct-entity tables: the queue's entity_id IS the row's own primary key, so
// we simply re-read that row from SQLite and upsert it to the same-named cloud
// table (the local and cloud schemas are intentionally identical — see §5.2).
//
// Task-child tables: several repositories (remarks, links, emails, location,
// meeting, travel plan, contacts-on-task) queue the *task's* id rather than a
// child row's id, because "this task's related data changed" is what matters.
// For those we resync every child row for that task — small tables, so this is
// cheap and trivially idempotent.
// ----------------------------------------------------------------------------

const DIRECT_TABLES: Record<string, string> = {
  task: 'tasks',
  contact: 'contacts',
  task_category: 'task_categories',
  attachment: 'attachments',
  calendar_event: 'calendar_events',
};

const TASK_CHILD_TABLES: Record<string, string> = {
  task_remark: 'task_remarks',
  task_link: 'task_links',
  task_email: 'task_emails',
  location: 'locations',
  meeting: 'meetings',
  travel_plan: 'travel_plans',
  task_contact: 'task_contacts',
};

let isRunning = false;
let timer: ReturnType<typeof setInterval> | null = null;

export function startSyncEngine() {
  if (timer) return;
  NetInfo.addEventListener((state) => {
    if (state.isConnected) runSyncCycle();
  });
  timer = setInterval(runSyncCycle, 30_000);
  runSyncCycle();
}

export function stopSyncEngine() {
  if (timer) clearInterval(timer);
  timer = null;
}

export async function runSyncCycle(): Promise<void> {
  if (isRunning) return;
  if (!isSupabaseConfigured()) return; // fully offline mode — nothing to do
  const net = await NetInfo.fetch();
  if (!net.isConnected) return;

  isRunning = true;
  try {
    const db = await getDb();
    const items = await db.getAllAsync<SyncQueueItem>(
      `SELECT * FROM sync_queue WHERE status IN ('queued','failed') ORDER BY created_at ASC LIMIT 25`
    );
    for (const item of items) {
      await processQueueItem(item).catch(async (err) => {
        await backoffItem(item, err);
      });
    }
  } finally {
    isRunning = false;
  }
}

async function processQueueItem(item: SyncQueueItem) {
  const db = await getDb();
  await db.runAsync(`UPDATE sync_queue SET status = 'in_flight' WHERE id = ?`, [item.id]);

  if (item.operation === 'UPLOAD_FILE') {
    await pushAttachmentFile(item.entity_id);
  } else if (item.operation === 'DELETE_FILE') {
    // Metadata row is already gone locally; nothing further to do without a
    // cloud row to point at (Phase 2: track storage_path before delete).
  } else if (DIRECT_TABLES[item.entity_type]) {
    await pushDirectRow(DIRECT_TABLES[item.entity_type], item.entity_id, item.operation);
  } else if (TASK_CHILD_TABLES[item.entity_type]) {
    await pushTaskChildren(TASK_CHILD_TABLES[item.entity_type], item.entity_id);
  }

  await db.runAsync(`DELETE FROM sync_queue WHERE id = ?`, [item.id]);
  notifyTablesChanged('sync_queue');
}

async function pushDirectRow(table: string, id: string, operation: SyncQueueItem['operation']) {
  const supabase = getSupabase();
  if (!supabase) return;
  const db = await getDb();

  if (operation === 'DELETE') {
    await supabase.from(table).update({ deleted_at: new Date().toISOString() }).eq('id', id);
    return;
  }

  const row = await db.getFirstAsync<Record<string, unknown>>(`SELECT * FROM ${table} WHERE id = ?`, [id]);
  if (!row) return;
  const { error } = await supabase.from(table).upsert(sanitizeRow(row));
  if (error) throw error;

  if (table === 'tasks' || table === 'attachments') {
    await db.runAsync(`UPDATE ${table} SET sync_status = 'synced' WHERE id = ?`, [id]);
    notifyTablesChanged(table === 'tasks' ? 'tasks' : 'attachments');
  }
}

async function pushTaskChildren(table: string, taskId: string) {
  const supabase = getSupabase();
  if (!supabase) return;
  const db = await getDb();
  const rows = await db.getAllAsync<Record<string, unknown>>(`SELECT * FROM ${table} WHERE task_id = ?`, [taskId]);
  if (rows.length === 0) return;
  const { error } = await supabase.from(table).upsert(rows.map(sanitizeRow));
  if (error) throw error;
}

async function pushAttachmentFile(attachmentId: string) {
  const supabase = getSupabase();
  if (!supabase) return;
  const db = await getDb();
  const row = await db.getFirstAsync<{ id: string; task_id: string; local_path: string | null; file_name: string; mime_type: string | null }>(
    'SELECT id, task_id, local_path, file_name, mime_type FROM attachments WHERE id = ?',
    [attachmentId]
  );
  if (!row || !row.local_path) return;

  const bytes = await readFileBytes(row.local_path);
  const storagePath = `${getCurrentUserId()}/${row.task_id}/${row.id}_${row.file_name}`;
  const { error: uploadError } = await supabase.storage
    .from(ATTACHMENTS_BUCKET)
    .upload(storagePath, bytes, { contentType: row.mime_type ?? undefined, upsert: true });
  if (uploadError) throw uploadError;

  await db.runAsync(`UPDATE attachments SET storage_path = ?, sync_status = 'synced' WHERE id = ?`, [storagePath, attachmentId]);
  const fullRow = await db.getFirstAsync<Record<string, unknown>>('SELECT * FROM attachments WHERE id = ?', [attachmentId]);
  if (fullRow) await supabase.from('attachments').upsert(sanitizeRow(fullRow));
  notifyTablesChanged('attachments');
}

/** Drops SQLite-only columns (0/1 booleans are fine in Postgres too) before upsert. */
function sanitizeRow(row: Record<string, unknown>): Record<string, unknown> {
  const clone = { ...row };
  return clone;
}

/** Exponential backoff: 2s, 4s, 8s, 16s ... capped at 5 minutes (ARCHITECTURE.md §4.1). */
async function backoffItem(item: SyncQueueItem, err: unknown) {
  const db = await getDb();
  const nextRetry = Math.min(item.retry_count + 1, 20);
  await db.runAsync(`UPDATE sync_queue SET status = 'failed', retry_count = ?, last_error = ? WHERE id = ?`, [
    nextRetry,
    String((err as Error)?.message ?? err),
    item.id,
  ]);
}
