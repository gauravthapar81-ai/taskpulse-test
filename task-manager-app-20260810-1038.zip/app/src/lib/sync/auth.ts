import { getSupabase } from './supabaseClient';

/** Returns the active Supabase session's user id, or null if signed out /
 * Supabase isn't configured. Reads from the persisted session (AsyncStorage)
 * first — no network round-trip required, so this resolves instantly even
 * offline once a device has signed in before. */
export async function getSupabaseSessionUserId(): Promise<string | null> {
  const supabase = getSupabase();
  if (!supabase) return null;
  const { data } = await supabase.auth.getSession();
  return data.session?.user.id ?? null;
}

export async function signInWithPassword(email: string, password: string) {
  const supabase = getSupabase();
  if (!supabase) throw new Error('Supabase is not configured');
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data.user?.id ?? null;
}

export async function signUpWithPassword(email: string, password: string, fullName: string) {
  const supabase = getSupabase();
  if (!supabase) throw new Error('Supabase is not configured');
  const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { full_name: fullName } } });
  if (error) throw error;
  return data.user?.id ?? null;
}

export async function signOutSupabase() {
  const supabase = getSupabase();
  if (!supabase) return;
  await supabase.auth.signOut();
}
