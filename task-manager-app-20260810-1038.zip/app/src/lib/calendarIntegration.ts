import * as Calendar from 'expo-calendar';
import { Platform } from 'react-native';

/** Adds an event to whatever calendar app is already on the phone (Req. #21).
 * This intentionally does NOT re-implement a calendar — it hands off to
 * Google Calendar (Android) / Apple Calendar (iOS) via EventKit/CalendarProvider,
 * which is what expo-calendar wraps. */
export async function addEventToDeviceCalendar(data: {
  title: string;
  startDate: Date;
  endDate: Date;
  location?: string;
  notes?: string;
}): Promise<string | null> {
  const { status } = await Calendar.requestCalendarPermissionsAsync();
  if (status !== 'granted') return null;

  const calendars = await Calendar.getCalendarsAsync(Calendar.EntityTypes.EVENT);
  let targetCalendar = calendars.find((c) => c.allowsModifications);

  if (!targetCalendar && Platform.OS === 'ios') {
    const defaultCal = await Calendar.getDefaultCalendarAsync();
    targetCalendar = defaultCal;
  }
  if (!targetCalendar && Platform.OS === 'android') {
    const source = { isLocalAccount: true, name: 'Task Manager', type: Calendar.SourceType.LOCAL } as any;
    const newCalId = await Calendar.createCalendarAsync({
      title: 'Task Manager',
      color: '#2452E8',
      entityType: Calendar.EntityTypes.EVENT,
      source,
      name: 'taskManagerCalendar',
      ownerAccount: 'personal',
      accessLevel: Calendar.CalendarAccessLevel.OWNER,
    });
    targetCalendar = { id: newCalId } as any;
  }
  if (!targetCalendar) return null;

  const eventId = await Calendar.createEventAsync(String(targetCalendar.id), {
    title: data.title,
    startDate: data.startDate,
    endDate: data.endDate,
    location: data.location,
    notes: data.notes,
  });
  return eventId;
}
