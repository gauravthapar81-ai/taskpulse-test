import React, { useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LabeledInput, PrimaryButton, SecondaryButton } from '../components/Common';
import { signInWithPassword, signUpWithPassword } from '../lib/sync/auth';
import { colors, spacing, typography } from '../theme/theme';

/**
 * Only ever shown when EXPO_PUBLIC_SUPABASE_URL/ANON_KEY are set AND there is
 * no existing Supabase session (see App.tsx). If Supabase isn't configured,
 * the app skips this entirely and runs on the local-only profile — this
 * screen exists solely so cloud sync has a real, stable auth.uid() to key
 * Row-Level Security off (ARCHITECTURE.md §5.3), not as a v1 requirement.
 */
export function AuthGateScreen({ onSignedIn, onSkip }: { onSignedIn: (userId: string) => void; onSkip: () => void }) {
  const [mode, setMode] = useState<'signIn' | 'signUp'>('signIn');
  const [fullName, setFullName] = useState('Gaurav');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit() {
    if (!email.trim() || !password) return Alert.alert('Enter your email and password');
    setLoading(true);
    try {
      const userId = mode === 'signIn' ? await signInWithPassword(email.trim(), password) : await signUpWithPassword(email.trim(), password, fullName);
      if (userId) onSignedIn(userId);
      else Alert.alert('Check your email', 'Confirm your address to finish signing up, then sign in.');
    } catch (e) {
      Alert.alert('Could not sign in', String((e as Error).message ?? e));
    } finally {
      setLoading(false);
    }
  }

  return (
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={styles.content}>
        <Ionicons name="cloud-done-outline" size={40} color={colors.brand} style={{ marginBottom: spacing.md }} />
        <Text style={styles.title}>Connect Cloud Sync</Text>
        <Text style={styles.subtitle}>Sign in to sync tasks across your devices. This is optional — the app works fully offline without it.</Text>

        {mode === 'signUp' && <LabeledInput label="Name" value={fullName} onChangeText={setFullName} />}
        <LabeledInput label="Email" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" />
        <LabeledInput label="Password" value={password} onChangeText={setPassword} secureTextEntry />

        <PrimaryButton label={loading ? 'Please wait...' : mode === 'signIn' ? 'Sign In' : 'Create Account'} onPress={submit} disabled={loading} />
        <SecondaryButton
          label={mode === 'signIn' ? "Don't have an account? Sign up" : 'Already have an account? Sign in'}
          onPress={() => setMode(mode === 'signIn' ? 'signUp' : 'signIn')}
        />
        <View style={{ height: spacing.lg }} />
        <SecondaryButton label="Skip for now — use offline" icon="cloud-offline-outline" color={colors.textMuted} onPress={onSkip} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: colors.bg },
  content: { padding: spacing.xl, paddingTop: 80 },
  title: { ...typography.display, color: colors.textPrimary, marginBottom: spacing.xs },
  subtitle: { ...typography.body, color: colors.textSecondary, marginBottom: spacing.xl },
});
