# Supabase Setup — turning on cloud sync

The app works completely without this. Skip it entirely if you only need it on
one phone. Do this when you want tasks to sync between Gaurav's devices (or
eventually with Abhay).

## 1. Create a project

1. Go to https://supabase.com, sign in, click **New project**.
2. Pick any name/region/password. Wait ~2 minutes for it to provision.

## 2. Run the schema

1. In your project, open **SQL Editor → New query**.
2. Open `docs/supabase/schema.sql` from this project, copy the entire file, paste it in, and click **Run**.
3. You should see "Success. No rows returned." This creates every table, the
   `attachments-private` storage bucket, and all Row-Level Security policies.

## 3. Enable email sign-in

1. Go to **Authentication → Providers**.
2. Make sure **Email** is enabled (it is by default).
3. If you don't want new sign-ups to require email confirmation while testing,
   go to **Authentication → Settings** and turn off "Confirm email" temporarily.

## 4. Get your API keys

1. Go to **Project Settings → API**.
2. Copy the **Project URL** and the **anon public** key (not the `service_role` key — never put that in the mobile app).

## 5. Add them to the app

In the `app/` folder, create a file named `.env` (copy `.env.example` if present) with:

```
EXPO_PUBLIC_SUPABASE_URL=https://your-project-ref.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-public-key
```

Restart `npx expo start` after adding this (environment variables are only read at startup).

## 6. Sign in on the device

With the keys in place, the next time you open the app it will show a **Connect
Cloud Sync** screen. Create an account with an email/password (this is the same
account you'd use on a second device), or tap **Skip for now** to keep using it
offline. Signing in re-attributes anything you already created locally to your
new account, so nothing you made while offline is lost.

## 7. Verify it's working

Open **More → Sync Status** in the app. It should say "Connected to a Supabase
project" and show 0 pending changes once everything has synced. In the
Supabase dashboard, **Table Editor → tasks** should show your tasks.

## What syncs automatically

Everything: tasks, categories, contacts, remarks, activity history,
reassignments, emails, links, locations, meetings, calendar events, travel
plans, reminders, and attachment files (uploaded to the private
`attachments-private` storage bucket). See `ARCHITECTURE.md` §4 for exactly how
the offline-first sync engine decides what to push and when.

## Adding Abhay as a second workspace member (optional, Phase 3+)

The schema already includes a `workspace_members` table for this. Once Abhay
has signed up with his own account, run this in the SQL Editor (replace the
UUIDs — find them in **Authentication → Users**):

```sql
insert into public.workspace_members (owner_id, member_id)
values ('<gaurav-user-id>', '<abhay-user-id>');
```

From then on, Abhay's signed-in device sees and can edit the same tasks.

## Troubleshooting

- **"Could not sign in"** — double-check the URL/anon key have no extra spaces, and that you restarted `expo start` after editing `.env`.
- **Sync Status always shows "Pending changes" going up, never down** — check **More → Sync Status**, and check your internet connection; the app retries automatically with backoff, nothing is lost.
- **A table looks empty in Supabase but has data on the phone** — the schema migration may not have run. Re-run `docs/supabase/schema.sql` (it's safe to run more than once).
