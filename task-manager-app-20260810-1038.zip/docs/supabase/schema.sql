-- ============================================================================
-- Gaurav's Task Manager — Supabase (PostgreSQL) schema
-- ============================================================================
-- Run this once, in full, in your Supabase project's SQL Editor
-- (Project → SQL Editor → New query → paste this whole file → Run).
--
-- This mirrors the local SQLite schema in app/src/db/database.ts table-for-table
-- (see ARCHITECTURE.md §5.2) so the Sync Engine (app/src/lib/sync/syncEngine.ts)
-- can upsert a local row straight into its same-named cloud table with no
-- translation step. Every syncable table carries the same six sync-metadata
-- columns described in ARCHITECTURE.md §4.3: version, sync_status, device_id,
-- created_at, updated_at, deleted_at.
--
-- Safe to re-run: every statement is guarded with IF NOT EXISTS / OR REPLACE.
-- ============================================================================

create extension if not exists pgcrypto;

-- ----------------------------------------------------------------------------
-- 1. USERS — mirrors auth.users; id MUST equal the Supabase Auth user id.
-- ----------------------------------------------------------------------------
create table if not exists public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text,
  phone text,
  avatar_url text,
  role text not null default 'assistant', -- 'owner' | 'assistant' | 'viewer'
  created_at timestamptz not null default now()
);

-- Auto-create a public.users row whenever someone signs up via Supabase Auth.
create or replace function public.handle_new_auth_user()
returns trigger as $$
begin
  insert into public.users (id, email, full_name, created_at)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', ''), now())
  on conflict (id) do nothing;
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_auth_user();

-- ----------------------------------------------------------------------------
-- 2. WORKSPACE MEMBERS — v1 ships single-workspace (just Gaurav's account).
--    This table exists so adding Abhay as a second member later (Phase 3+)
--    needs zero schema changes — see ARCHITECTURE.md §5.3.
-- ----------------------------------------------------------------------------
create table if not exists public.workspace_members (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.users(id) on delete cascade,
  member_id uuid not null references public.users(id) on delete cascade,
  role text not null default 'member',
  created_at timestamptz not null default now(),
  unique (owner_id, member_id)
);

-- ----------------------------------------------------------------------------
-- 3. DEVICES
-- ----------------------------------------------------------------------------
create table if not exists public.devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.users(id) on delete cascade,
  device_name text not null,
  platform text not null,
  push_token text,
  last_seen_at timestamptz,
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- 4. TASK CATEGORIES
-- ----------------------------------------------------------------------------
create table if not exists public.task_categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  color_hex text not null,
  icon text not null,
  is_default boolean not null default false,
  sort_order integer not null default 0,
  created_by uuid references public.users(id),
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- 5. TASKS — the hub table (ARCHITECTURE.md §5.1)
-- ----------------------------------------------------------------------------
create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  category_id uuid not null references public.task_categories(id),
  priority text not null default 'P2' check (priority in ('P1','P2','P3')),
  status text not null default 'pending'
    check (status in ('pending','in_progress','completed','on_hold','cancelled','reassigned')),
  assigned_to_name text,
  assigned_to_contact_id uuid,
  created_by uuid not null references public.users(id),
  pending_since timestamptz not null default now(),
  due_date timestamptz,
  reminder_at timestamptz,
  is_starred boolean not null default false,
  completed_at timestamptz,
  version integer not null default 1,
  sync_status text not null default 'synced',
  device_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);
create index if not exists idx_tasks_status on public.tasks(status);
create index if not exists idx_tasks_category on public.tasks(category_id);
create index if not exists idx_tasks_due on public.tasks(due_date);
create index if not exists idx_tasks_created_by on public.tasks(created_by);

-- ----------------------------------------------------------------------------
-- 6. TASK REASSIGNMENTS (append-only history — Req. #7)
-- ----------------------------------------------------------------------------
create table if not exists public.task_reassignments (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  from_name text,
  to_name text not null,
  reason text,
  remark text,
  changed_by uuid references public.users(id),
  changed_at timestamptz not null default now()
);
create index if not exists idx_reassign_task on public.task_reassignments(task_id);

-- ----------------------------------------------------------------------------
-- 7. TASK REMARKS (append-only timeline — Req. #8)
-- ----------------------------------------------------------------------------
create table if not exists public.task_remarks (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  body text not null,
  author_id uuid references public.users(id),
  original_language text not null default 'en',
  created_at timestamptz not null default now()
);
create index if not exists idx_remarks_task on public.task_remarks(task_id);

-- ----------------------------------------------------------------------------
-- 8. TASK ACTIVITY (auto-generated system log — Req. #40)
-- ----------------------------------------------------------------------------
create table if not exists public.task_activity (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  event_type text not null,
  description text not null,
  actor_device_id text,
  created_at timestamptz not null default now()
);
create index if not exists idx_activity_task on public.task_activity(task_id);

-- ----------------------------------------------------------------------------
-- 9. CONTACTS
-- ----------------------------------------------------------------------------
create table if not exists public.contacts (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  mobile text,
  alternate_mobile text,
  email text,
  company text,
  designation text,
  remarks text,
  created_by uuid references public.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

-- 10. TASK <-> CONTACT junction
create table if not exists public.task_contacts (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  contact_id uuid not null references public.contacts(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (task_id, contact_id)
);
create index if not exists idx_task_contacts_task on public.task_contacts(task_id);

-- 11. TASK EMAILS
create table if not exists public.task_emails (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  email_address text not null,
  subject text,
  body text,
  created_at timestamptz not null default now()
);
create index if not exists idx_task_emails_task on public.task_emails(task_id);

-- 12. TASK LINKS (web + meeting links)
create table if not exists public.task_links (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  link_type text not null check (link_type in ('website','meeting_google_meet','meeting_teams','meeting_zoom','meeting_other')),
  label text,
  url text not null,
  created_at timestamptz not null default now()
);
create index if not exists idx_task_links_task on public.task_links(task_id);

-- 13. LOCATIONS (Google Maps)
create table if not exists public.locations (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  label text,
  address text,
  maps_url text,
  latitude double precision,
  longitude double precision,
  created_at timestamptz not null default now()
);
create index if not exists idx_locations_task on public.locations(task_id);

-- 14. MEETINGS (lightweight, tied to a task)
create table if not exists public.meetings (
  id uuid primary key default gen_random_uuid(),
  task_id uuid references public.tasks(id) on delete cascade,
  title text not null,
  start_time timestamptz not null,
  end_time timestamptz,
  location text,
  meeting_link text,
  participants text,
  remarks text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_meetings_task on public.meetings(task_id);
create index if not exists idx_meetings_start on public.meetings(start_time);

-- 15. CALENDAR EVENTS
create table if not exists public.calendar_events (
  id uuid primary key default gen_random_uuid(),
  task_id uuid references public.tasks(id) on delete cascade,
  title text not null,
  start_time timestamptz not null,
  end_time timestamptz not null,
  location text,
  meeting_link text,
  participants text,
  remarks text,
  provider text default 'device' check (provider in ('device','google','apple')),
  external_event_id text,
  created_at timestamptz not null default now()
);
create index if not exists idx_cal_events_task on public.calendar_events(task_id);
create index if not exists idx_cal_events_start on public.calendar_events(start_time);

-- 16. TRAVEL PLANS
create table if not exists public.travel_plans (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  city text not null,
  travel_date timestamptz not null,
  return_date timestamptz,
  purpose text,
  hotel_name text,
  hotel_address text,
  travel_booking_link text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_travel_task on public.travel_plans(task_id);

-- 17. ATTACHMENTS — metadata only; bytes live in Storage (see §5.4 below)
create table if not exists public.attachments (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  file_type text not null check (file_type in ('image','pdf','audio','video')),
  file_name text not null,
  file_size_bytes bigint,
  mime_type text,
  duration_seconds integer,
  local_path text, -- meaningful on-device only; harmless to keep in the cloud row
  storage_path text, -- path inside the attachments-private bucket, set once uploaded
  uploaded_by uuid references public.users(id),
  sync_status text not null default 'synced',
  created_at timestamptz not null default now()
);
create index if not exists idx_attachments_task on public.attachments(task_id);

-- 18. REMINDERS
create table if not exists public.reminders (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  remind_at timestamptz not null,
  message text,
  is_sent boolean not null default false,
  notification_id text,
  created_at timestamptz not null default now()
);
create index if not exists idx_reminders_task on public.reminders(task_id);

-- ============================================================================
-- ROW LEVEL SECURITY
-- ============================================================================
-- v1 policy: a user can read/write their own rows, or rows belonging to a
-- workspace owner who has added them as a member (ARCHITECTURE.md §5.3).
-- ============================================================================

create or replace function public.in_same_workspace(row_owner uuid)
returns boolean as $$
  select auth.uid() = row_owner
     or exists (
       select 1 from public.workspace_members wm
       where wm.owner_id = row_owner and wm.member_id = auth.uid()
     )
     or exists (
       select 1 from public.workspace_members wm
       where wm.owner_id = auth.uid() and wm.member_id = row_owner
     );
$$ language sql stable security definer;

alter table public.users enable row level security;
alter table public.devices enable row level security;
alter table public.task_categories enable row level security;
alter table public.tasks enable row level security;
alter table public.task_reassignments enable row level security;
alter table public.task_remarks enable row level security;
alter table public.task_activity enable row level security;
alter table public.contacts enable row level security;
alter table public.task_contacts enable row level security;
alter table public.task_emails enable row level security;
alter table public.task_links enable row level security;
alter table public.locations enable row level security;
alter table public.meetings enable row level security;
alter table public.calendar_events enable row level security;
alter table public.travel_plans enable row level security;
alter table public.attachments enable row level security;
alter table public.reminders enable row level security;
alter table public.workspace_members enable row level security;

drop policy if exists "self" on public.users;
create policy "self" on public.users for all using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists "own devices" on public.devices;
create policy "own devices" on public.devices for all using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists "workspace categories" on public.task_categories;
create policy "workspace categories" on public.task_categories for all
  using (created_by is null or public.in_same_workspace(created_by))
  with check (created_by is null or public.in_same_workspace(created_by));

drop policy if exists "workspace tasks" on public.tasks;
create policy "workspace tasks" on public.tasks for all
  using (public.in_same_workspace(created_by))
  with check (public.in_same_workspace(created_by));

-- Child tables inherit access through their parent task's workspace.
drop policy if exists "workspace task_reassignments" on public.task_reassignments;
create policy "workspace task_reassignments" on public.task_reassignments for all
  using (exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)))
  with check (exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)));

drop policy if exists "workspace task_remarks" on public.task_remarks;
create policy "workspace task_remarks" on public.task_remarks for all
  using (exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)))
  with check (exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)));

drop policy if exists "workspace task_activity" on public.task_activity;
create policy "workspace task_activity" on public.task_activity for all
  using (exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)))
  with check (exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)));

drop policy if exists "workspace contacts" on public.contacts;
create policy "workspace contacts" on public.contacts for all
  using (created_by is null or public.in_same_workspace(created_by))
  with check (created_by is null or public.in_same_workspace(created_by));

drop policy if exists "workspace task_contacts" on public.task_contacts;
create policy "workspace task_contacts" on public.task_contacts for all
  using (exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)))
  with check (exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)));

drop policy if exists "workspace task_emails" on public.task_emails;
create policy "workspace task_emails" on public.task_emails for all
  using (exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)))
  with check (exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)));

drop policy if exists "workspace task_links" on public.task_links;
create policy "workspace task_links" on public.task_links for all
  using (exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)))
  with check (exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)));

drop policy if exists "workspace locations" on public.locations;
create policy "workspace locations" on public.locations for all
  using (exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)))
  with check (exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)));

drop policy if exists "workspace meetings" on public.meetings;
create policy "workspace meetings" on public.meetings for all
  using (task_id is null or exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)))
  with check (task_id is null or exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)));

drop policy if exists "workspace calendar_events" on public.calendar_events;
create policy "workspace calendar_events" on public.calendar_events for all
  using (task_id is null or exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)))
  with check (task_id is null or exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)));

drop policy if exists "workspace travel_plans" on public.travel_plans;
create policy "workspace travel_plans" on public.travel_plans for all
  using (exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)))
  with check (exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)));

drop policy if exists "workspace attachments" on public.attachments;
create policy "workspace attachments" on public.attachments for all
  using (exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)))
  with check (exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)));

drop policy if exists "workspace reminders" on public.reminders;
create policy "workspace reminders" on public.reminders for all
  using (exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)))
  with check (exists (select 1 from public.tasks t where t.id = task_id and public.in_same_workspace(t.created_by)));

drop policy if exists "own workspace_members rows" on public.workspace_members;
create policy "own workspace_members rows" on public.workspace_members for all
  using (owner_id = auth.uid() or member_id = auth.uid())
  with check (owner_id = auth.uid());

-- ============================================================================
-- STORAGE — private bucket for images/PDF/audio/video (ARCHITECTURE.md §5.4)
-- ============================================================================
insert into storage.buckets (id, name, public)
values ('attachments-private', 'attachments-private', false)
on conflict (id) do nothing;

drop policy if exists "workspace can read own attachment files" on storage.objects;
create policy "workspace can read own attachment files" on storage.objects for select
  using (bucket_id = 'attachments-private' and public.in_same_workspace((storage.foldername(name))[1]::uuid));

drop policy if exists "workspace can upload own attachment files" on storage.objects;
create policy "workspace can upload own attachment files" on storage.objects for insert
  with check (bucket_id = 'attachments-private' and public.in_same_workspace((storage.foldername(name))[1]::uuid));

drop policy if exists "workspace can update own attachment files" on storage.objects;
create policy "workspace can update own attachment files" on storage.objects for update
  using (bucket_id = 'attachments-private' and public.in_same_workspace((storage.foldername(name))[1]::uuid));

drop policy if exists "workspace can delete own attachment files" on storage.objects;
create policy "workspace can delete own attachment files" on storage.objects for delete
  using (bucket_id = 'attachments-private' and public.in_same_workspace((storage.foldername(name))[1]::uuid));

-- The app uploads to storage paths shaped like {user_id}/{task_id}/{attachment_id}_{filename}
-- (see app/src/lib/sync/syncEngine.ts), so (storage.foldername(name))[1] is always the owner's user id.

-- ============================================================================
-- Done. Next: copy your Project URL + anon key (Project Settings → API) into
-- EXPO_PUBLIC_SUPABASE_URL / EXPO_PUBLIC_SUPABASE_ANON_KEY — see SUPABASE_SETUP.md.
-- ============================================================================
