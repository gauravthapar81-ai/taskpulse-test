# Gaurav's Task Manager — System Architecture & Data Model (v1.0)

**Owner:** Abhay Singavi / Redcliffe Labs — primary daily user: Gaurav
**Prepared:** 08-Aug-2026
**Status:** Living document — update as features are added.

---

## 1. Design Philosophy

> "I should be able to create and update a task within seconds."

This is not an enterprise ERP. It is a personal executive-assistant app. Every architectural
decision is judged against three tests:

1. **Local-first, cloud-second.** The app must never wait on the network to feel usable. Every
   write lands on-device instantly; syncing to the cloud happens silently afterward.
2. **One task, many facets.** A task is a container that can simultaneously hold contacts,
   emails, links, a location, a meeting, a calendar event, travel details, and any number of
   attachments (images/PDF/audio/video) — never a 1:1 relationship.
3. **Nothing is ever silently lost.** Reassignments, remarks, and status changes are appended to
   an immutable activity trail, never overwritten. Deletes are soft deletes.

---

## 2. Technology Stack

> **Note on framework choice:** the original recommendation for this project was Flutter +
> Drift + Supabase. That data/sync architecture is preserved in full below. The client framework
> was switched to **React Native (Expo)** for one practical reason: this build was produced in a
> sandboxed cloud environment whose network allowlist cannot reach the Flutter/Dart toolchain
> (`storage.googleapis.com`, `pub.dev`), so Flutter code could not be installed, compiled, or
> verified there. React Native/Expo uses the npm registry, which is reachable, so the app below
> was actually built, type-checked, and is runnable today via Expo Go with no local SDK
> installation. Every other decision — offline-first SQLite, Supabase Postgres, UUIDs, sync
> queue, field-level conflict resolution — is unchanged and is not framework-specific.

| Layer | Choice | Why |
|---|---|---|
| Mobile/Web client | **React Native + Expo** (TypeScript, single codebase for iOS + Android + Web) | One codebase for all 3 targets, excellent native module ecosystem, and — critically — testable instantly on a real phone via the Expo Go app (scan a QR code, no Xcode/Android Studio required for day-to-day development). |
| State/reactivity | **Zustand** (small global stores: session, connectivity, UI state) + a hand-rolled `useLiveQuery` hook (`src/db/useLiveQuery.ts`) | A local pub/sub emits a table-changed event after every write; any screen's query hook subscribed to that table re-runs automatically. This reproduces Drift's "reactive stream" UX (UI updates the instant a row changes, no pull-to-refresh) without needing a heavier data-fetching library, since all reads are local and synchronous-ish. |
| Local database | **expo-sqlite** (SQLite) with a typed repository layer (`src/db/repositories/*`) | Type-safe query functions per table, hand-written against the schema in §5 rather than generated — this avoids depending on `drizzle-kit`'s CLI (which needs an interactive migration-generation step) while keeping every read/write fully typed in TypeScript. The table shapes are unchanged from the original Drift design, so migrating to Drizzle or Drift-for-RN later is a mechanical swap, not a redesign. |
| Cloud database | **Supabase (PostgreSQL)** | Structured relational data (tasks/contacts/meetings/history) fits relational modelling far better than a document store. Comes with Auth, Storage, and Realtime out of the box. |
| File storage | **Supabase Storage** (private buckets) | Images/PDF/audio/video metadata lives in Postgres; the bytes live in Storage, referenced by `storage_path`. |
| Auth | **Supabase Auth** (email/password now; Google + Apple Sign-In wired for later) | Managed, secure, works with Row-Level Security automatically. |
| Push notifications | **expo-notifications** (local, on-device scheduling) now; Firebase Cloud Messaging for cross-device push in Phase 3 | `expo-notifications` handles local reminders offline with zero extra backend; FCM is layered on when a reminder needs to reach a second device. |
| Maps | **Google Maps** via `Linking.openURL('https://maps.google.com/?q=...')` in v1; `react-native-maps` is a drop-in upgrade later | Universally available, no extra API key needed for v1. |
| Calendar | **expo-calendar** (wraps EventKit on iOS / CalendarContract on Android) in v1; **Google Calendar API** as a v1.1 integration | Lets Gaurav add an event to whatever calendar app is already on the phone without us re-implementing a calendar. |
| Meeting links | `Linking.openURL()` — Meet/Teams/Zoom links are just URLs | No SDK integration needed to make a link clickable. |
| Sharing | React Native's built-in `Share` API (text) + `expo-sharing` (files) | Native share sheet on both platforms. |
| Audio/Video | `expo-av` (record/playback for audio, playback for video) | One well-maintained Expo module covering both recording and playback; outputs M4A (AAC) which is natively playable on both platforms. |
| Camera/Gallery/Files | `expo-image-picker`, `expo-document-picker` | Standard Expo modules, no config plugins beyond what Expo Go already includes. |
| Contacts (device) | `expo-contacts` | Powers the "Save Contact" action from a task's contact card. |

We deliberately did **not** choose Firebase/Firestore as the system of record — Firestore's
document model fights the highly relational shape of this data (tasks → assignments →
reassignments → remarks → activity → attachments, all with real foreign keys and joins).
Firebase Cloud Messaging remains an option purely for cross-device push delivery, not data storage.

---

## 3. High-Level Architecture

```
                         iOS / Android / Web
                                 │
                                 ▼
                React Native Application (Expo, Zustand)
                                 │
                 ┌───────────────┴───────────────┐
                 │                                │
                 ▼                                ▼
        Local expo-sqlite (SQLite)            Sync Engine
        (source of truth for UI)          (JS async task loop)
                 │                                │
                 │                     ┌───────────┴───────────┐
                 │                     │   Internet available?  │
                 │                     └───────────┬───────────┘
                 │                                 ▼
                 │                         Supabase Auth (JWT)
                 │                                 │
                 │                                 ▼
                 │                        PostgreSQL (Supabase)
                 │                                 │
                 │                    ┌────────────┴────────────┐
                 │                    ▼                         ▼
                 │           Supabase Storage             Realtime channel
                 │         (images/pdf/audio/video)    (push changes back down
                 │                                      to other devices)
                 └───────────────────────────────────────────────┘
                        (Realtime changes are merged back into
                         local Drift so all screens update live)
```

**Every screen reads only from local SQLite.** No screen ever blocks on a network call. The Sync
Engine is the only thing that talks to Supabase, and it runs continuously in the background.

---

## 4. Offline-First Sync Architecture

### 4.1 Write path (the golden rule)

```
User action (create/edit/reassign/remark/status change/attach file)
        ↓
Write immediately to local SQLite table   ← useLiveQuery re-runs instantly, UI updates with no refresh
        ↓
Row's sync_status set to "pending_upload" / "pending_update" / "pending_delete"
        ↓
A row is appended to sync_queue (entity_type, entity_id, operation, payload snapshot)
        ↓
Sync Engine wakes (on connectivity change, app foreground, or a 30s timer)
        ↓
Uploads queued rows to Supabase in dependency order (parents before children)
        ↓
On 2xx response → mark local row sync_status = "synced", store server updated_at
On failure      → retry_count++, exponential backoff (2s, 4s, 8s ... capped at 5 min), row stays
                  visible and editable locally the whole time
```

No "Sync" button ever appears. A small, unobtrusive status dot (grey = synced, amber = pending,
red = conflict) can optionally appear on the task card for transparency, but sync is otherwise
invisible.

### 4.2 Identity: UUIDs everywhere

Every table's primary key is a `TEXT` UUID (v4), generated **client-side at creation time**. This
is what makes offline creation safe — two devices can create rows simultaneously with zero risk
of collision, and a task created on the phone in airplane mode already has its permanent ID
before it ever reaches the server.

### 4.3 Versioning & conflict resolution

Every syncable row carries:

```
version         INTEGER   -- incremented on every write, local or server
updated_at      TIMESTAMPTZ
last_synced_at  TIMESTAMPTZ
device_id       TEXT      -- which device made the last change
sync_status     TEXT      -- synced | pending_upload | pending_update | pending_delete | conflict
deleted_at      TIMESTAMPTZ NULL   -- soft delete
```

Resolution strategy is **field-level merge, not row-level overwrite**:

- The Sync Engine uploads a *diff* (only the columns that changed locally), not the whole row.
- Postgres applies each incoming field with `last-write-wins` compared by `updated_at`
  **per field**, using a Postgres trigger that tracks per-column last-write timestamps in a
  companion `_field_versions` JSONB column.
- If the *same field* was changed on two devices before either synced, the later `updated_at`
  wins for that field, and a row is written to `task_activity` recording both attempted values
  ("Priority changed to P1 (phone) — conflicting change to P2 (tablet) discarded, kept P1 as most
  recent") so nothing is silently lost from the human's point of view.
- If *different fields* were changed (e.g. priority on one device, status on another), both
  changes are simply merged — this is the common case and requires no special handling.
- The row's `sync_status` is only set to `conflict` (and surfaced to the user with a small badge)
  when the same field changed on two devices within the same sync window and we want a human to
  confirm — this is intentionally rare.

### 4.4 Attachments have their own queue

Binary files never go through the row-diff mechanism above. Each attachment gets its own
`sync_queue` entry with `operation = UPLOAD_FILE`:

```
Record/pick file → save to app's local documents dir → insert `attachments` row
(sync_status = pending_upload, local_path set, storage_path = NULL)
        ↓
Sync Engine uploads bytes to Supabase Storage (chunked/resumable for files > 6MB)
        ↓
On success → storage_path set, sync_status = synced
On failure → retry with backoff; local_path keeps the file playable/viewable meanwhile
```

Large video uploads never block task creation — the task and its metadata sync immediately; only
the bytes trickle up in the background.

### 4.5 Devices

A `devices` table records every installation (`device_id`, `platform`, `device_name`,
`last_seen_at`) tied to a `user_id`. This lets a future "Devices" settings screen show "Gaurav's
iPhone — last synced 2 min ago / Gaurav's Android — last synced yesterday" and lets activity
history attribute a change to "Reassigned to Mohit (from Gaurav's iPhone)".

---

## 5. Data Model

### 5.1 Entity relationship overview

```
users ──< devices
users ──< tasks ──< task_reassignments
              ├──< task_remarks
              ├──< task_activity
              ├──< task_contacts >── contacts
              ├──< task_links
              ├──< attachments
              ├──< reminders
              ├── meeting (0..1)            (meetings)
              ├── calendar_event (0..1)     (calendar_events)
              ├── travel_plan (0..1)        (travel_plans)
              └── location (0..1)           (locations)
task_categories ──< tasks
```

A task is deliberately a hub, not a leaf — this is what lets "Mumbai Client Meeting" carry a
contact, an email, a PDF ticket, a hotel location, a calendar invite, and a remark thread all at
once (Req. #25).

### 5.2 Core tables (identical shape locally in SQLite and in Supabase Postgres — this is what
makes sync straightforward: the local schema *is* the cloud schema, plus the sync-metadata
columns described in §4.3)

```sql
-- USERS (Supabase auth.users is the source of truth; this mirrors public profile fields)
users (
  id                UUID PRIMARY KEY,          -- = auth.users.id
  full_name         TEXT NOT NULL,
  email             TEXT,
  phone             TEXT,
  avatar_url        TEXT,
  role              TEXT DEFAULT 'assistant',  -- 'owner' | 'assistant' | 'viewer' (future multi-user)
  created_at        TIMESTAMPTZ NOT NULL
)

-- DEVICES
devices (
  id                UUID PRIMARY KEY,
  user_id           UUID NOT NULL REFERENCES users(id),
  device_name       TEXT NOT NULL,             -- "Gaurav's iPhone"
  platform          TEXT NOT NULL,             -- ios | android | web
  push_token        TEXT,
  last_seen_at      TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL
)

-- TASK CATEGORIES (Personal/Official/Travel/Urgent ship as seed data; user can add more)
task_categories (
  id                UUID PRIMARY KEY,
  name              TEXT NOT NULL,
  color_hex         TEXT NOT NULL,             -- for card accent color
  icon              TEXT NOT NULL,             -- icon key
  is_default        BOOLEAN DEFAULT FALSE,     -- true for the 4 seeded categories
  sort_order        INTEGER DEFAULT 0,
  created_by        UUID REFERENCES users(id),
  created_at        TIMESTAMPTZ NOT NULL
)

-- TASKS (the hub)
tasks (
  id                UUID PRIMARY KEY,
  title             TEXT NOT NULL,
  category_id       UUID NOT NULL REFERENCES task_categories(id),
  priority          TEXT NOT NULL,             -- P1 | P2 | P3
  status            TEXT NOT NULL DEFAULT 'pending', -- pending|in_progress|completed|on_hold|cancelled|reassigned
  assigned_to_name  TEXT,                      -- free-text ("Raman") — v1 does not require assignee to be an app user
  assigned_to_contact_id UUID REFERENCES contacts(id) NULL,
  created_by        UUID NOT NULL REFERENCES users(id),
  pending_since     TIMESTAMPTZ NOT NULL,      -- set at creation, reset when reassigned/reopened
  due_date          TIMESTAMPTZ,
  reminder_at       TIMESTAMPTZ,
  is_starred        BOOLEAN DEFAULT FALSE,
  completed_at      TIMESTAMPTZ,
  -- sync metadata (every syncable table repeats these 6 columns)
  version           INTEGER NOT NULL DEFAULT 1,
  sync_status       TEXT NOT NULL DEFAULT 'pending_upload',
  device_id         TEXT,
  created_at        TIMESTAMPTZ NOT NULL,
  updated_at        TIMESTAMPTZ NOT NULL,
  deleted_at        TIMESTAMPTZ
)

-- TASK REASSIGNMENT HISTORY (append-only)
task_reassignments (
  id                UUID PRIMARY KEY,
  task_id           UUID NOT NULL REFERENCES tasks(id),
  from_name         TEXT,
  to_name           TEXT NOT NULL,
  reason            TEXT,
  remark            TEXT,
  changed_by        UUID REFERENCES users(id),
  changed_at        TIMESTAMPTZ NOT NULL
)

-- TASK REMARKS / TIMELINE (append-only, never edited or overwritten)
task_remarks (
  id                UUID PRIMARY KEY,
  task_id           UUID NOT NULL REFERENCES tasks(id),
  body              TEXT NOT NULL,
  author_id         UUID REFERENCES users(id),
  original_language TEXT DEFAULT 'en',
  created_at        TIMESTAMPTZ NOT NULL
)

-- TASK ACTIVITY (auto-generated system log — "what happened")
task_activity (
  id                UUID PRIMARY KEY,
  task_id           UUID NOT NULL REFERENCES tasks(id),
  event_type        TEXT NOT NULL,   -- created|assigned|reassigned|status_changed|priority_changed|
                                       -- remark_added|attachment_added|due_date_changed|completed|
                                       -- reminder_set|conflict_resolved
  description       TEXT NOT NULL,   -- human-readable, pre-rendered: "Priority changed P2 → P1"
  actor_device_id    TEXT,
  created_at        TIMESTAMPTZ NOT NULL
)

-- CONTACTS (reusable address book, also embeddable per-task)
contacts (
  id                UUID PRIMARY KEY,
  name              TEXT NOT NULL,
  mobile            TEXT,
  alternate_mobile  TEXT,
  email             TEXT,
  company           TEXT,
  designation       TEXT,
  remarks           TEXT,
  created_by        UUID REFERENCES users(id),
  created_at        TIMESTAMPTZ NOT NULL,
  updated_at        TIMESTAMPTZ NOT NULL,
  deleted_at        TIMESTAMPTZ
)

-- TASK <-> CONTACT junction (many-to-many: a task can list multiple contacts)
task_contacts (
  id                UUID PRIMARY KEY,
  task_id           UUID NOT NULL REFERENCES tasks(id),
  contact_id        UUID NOT NULL REFERENCES contacts(id),
  created_at        TIMESTAMPTZ NOT NULL
)

-- EMAILS attached to a task (subject/body/address — not a mail server, just structured notes)
task_emails (
  id                UUID PRIMARY KEY,
  task_id           UUID NOT NULL REFERENCES tasks(id),
  email_address     TEXT NOT NULL,
  subject           TEXT,
  body              TEXT,
  created_at        TIMESTAMPTZ NOT NULL
)

-- LINKS (web links AND meeting links — same shape, `link_type` distinguishes)
task_links (
  id                UUID PRIMARY KEY,
  task_id           UUID NOT NULL REFERENCES tasks(id),
  link_type         TEXT NOT NULL,   -- website | meeting_google_meet | meeting_teams | meeting_zoom | meeting_other
  label             TEXT,
  url               TEXT NOT NULL,
  created_at        TIMESTAMPTZ NOT NULL
)

-- LOCATIONS (Google Maps)
locations (
  id                UUID PRIMARY KEY,
  task_id           UUID NOT NULL REFERENCES tasks(id),
  label             TEXT,            -- "Client Office – Gurgaon"
  address           TEXT,
  maps_url          TEXT,            -- pasted Google Maps link, or generated from lat/lng
  latitude          REAL,
  longitude         REAL,
  created_at        TIMESTAMPTZ NOT NULL
)

-- MEETINGS (lightweight — quick "10:00 AM call" without a full calendar event)
meetings (
  id                UUID PRIMARY KEY,
  task_id           UUID REFERENCES tasks(id),
  title             TEXT NOT NULL,
  start_time        TIMESTAMPTZ NOT NULL,
  end_time          TIMESTAMPTZ,
  location          TEXT,
  meeting_link      TEXT,
  participants      TEXT,            -- comma-separated for v1; normalize to a join table later
  remarks           TEXT,
  created_at        TIMESTAMPTZ NOT NULL,
  updated_at        TIMESTAMPTZ NOT NULL
)

-- CALENDAR EVENTS (mirrors what's been pushed to the device's Google/Apple calendar)
calendar_events (
  id                UUID PRIMARY KEY,
  task_id           UUID REFERENCES tasks(id),
  title             TEXT NOT NULL,
  start_time        TIMESTAMPTZ NOT NULL,
  end_time          TIMESTAMPTZ NOT NULL,
  location          TEXT,
  meeting_link      TEXT,
  participants      TEXT,
  remarks           TEXT,
  provider          TEXT,            -- device | google | apple
  external_event_id TEXT,            -- id returned by Google/Apple once v1.1 integration lands
  created_at        TIMESTAMPTZ NOT NULL
)

-- TRAVEL PLANS
travel_plans (
  id                UUID PRIMARY KEY,
  task_id           UUID NOT NULL REFERENCES tasks(id),
  city              TEXT NOT NULL,
  travel_date       TIMESTAMPTZ NOT NULL,
  return_date       TIMESTAMPTZ,
  purpose           TEXT,
  hotel_name        TEXT,
  hotel_address     TEXT,
  travel_booking_link TEXT,
  created_at        TIMESTAMPTZ NOT NULL,
  updated_at        TIMESTAMPTZ NOT NULL
)

-- ATTACHMENTS (images/pdf/audio/video — one task can have many, of mixed types)
attachments (
  id                UUID PRIMARY KEY,
  task_id           UUID NOT NULL REFERENCES tasks(id),
  file_type         TEXT NOT NULL,   -- image | pdf | audio | video
  file_name         TEXT NOT NULL,
  file_size_bytes   INTEGER,
  mime_type         TEXT,
  duration_seconds  INTEGER,          -- audio/video only
  local_path        TEXT,             -- always populated immediately (local-first)
  storage_path      TEXT,             -- populated once uploaded to Supabase Storage
  uploaded_by       UUID REFERENCES users(id),
  sync_status       TEXT NOT NULL DEFAULT 'pending_upload',
  created_at        TIMESTAMPTZ NOT NULL
)

-- REMINDERS (local notification schedule; independent of due_date so multiple reminders/task work)
reminders (
  id                UUID PRIMARY KEY,
  task_id           UUID NOT NULL REFERENCES tasks(id),
  remind_at         TIMESTAMPTZ NOT NULL,
  message           TEXT,
  is_sent           BOOLEAN DEFAULT FALSE,
  created_at        TIMESTAMPTZ NOT NULL
)

-- SYNC QUEUE (local-only table, never synced itself)
sync_queue (
  id                TEXT PRIMARY KEY,   -- local autoincrement is fine, this table never leaves the device
  entity_type       TEXT NOT NULL,      -- 'task' | 'attachment' | 'contact' | ...
  entity_id         TEXT NOT NULL,
  operation         TEXT NOT NULL,      -- CREATE | UPDATE | DELETE | UPLOAD_FILE | DELETE_FILE
  payload           TEXT,               -- JSON snapshot of changed fields
  retry_count       INTEGER DEFAULT 0,
  last_error        TEXT,
  status            TEXT DEFAULT 'queued',  -- queued | in_flight | failed | done
  created_at        TIMESTAMPTZ NOT NULL
)
```

Every table above except `sync_queue` and `devices` exists **identically** in SQLite (local) and
Postgres (cloud) — the sync engine is a straight row/field copier, not a translator, which is
what keeps it maintainable.

### 5.3 Row-Level Security (Supabase)

Every cloud table has RLS enabled. v1 policy (single owner + one assistant sharing everything):

```sql
create policy "owner and assistant can read/write their workspace"
on tasks for all
using (created_by = auth.uid() or exists (
  select 1 from workspace_members wm where wm.user_id = auth.uid()
))
with check (created_by = auth.uid() or exists (
  select 1 from workspace_members wm where wm.user_id = auth.uid()
));
```

A `workspace_members` table (v1.1) lets Abhay's and Gaurav's accounts share one workspace without
opening data to the public. v1 ships with a single-user workspace (Gaurav's account) and this
table stubbed in, ready to add Abhay as a second member without a schema change.

### 5.4 Storage buckets

```
attachments-private/
  {user_id}/{task_id}/{attachment_id}.{ext}
```

Bucket is **private**. The app requests a signed URL (60-minute TTL) from Supabase only at the
moment a file is opened/played/shared — never a permanent public URL.

---

## 6. Screens & Navigation

Bottom navigation (5 tabs + persistent FAB, per Req. #37):

```
HOME        Today's meetings + pending tasks + smart counts (default landing screen)
TASKS       All tasks, full search + filters
CALENDAR    Meetings & calendar events, day/week view
TRAVEL      Travel plans list + travel-specific task view
CONTACTS    Saved contacts, tap-to-call/WhatsApp/email
MORE        (accessed via icon, not a 6th tab) Settings, categories, backup/sync status, devices
```

`+ NEW TASK` is a floating action button, visible on every tab, one tap from anywhere (Req. #33
combined with #37).

Task detail screen layout (Req. #27) — header block (title/category/priority/status/assigned
to/dates) → tabbed or scrollable sections (Remarks timeline, Contact, Email, Meeting, Calendar,
Location, Attachments, Travel, Links, Reassignment history) → sticky bottom action bar
(Edit | Reassign | Complete | Share).

New Task flow (Req. #38) — a single screen: required fields up top (Name, Category, Priority,
Assigned To, Due Date, Reminder, Remarks), and an "Add more" row of chips (+Contact +Email
+Attachment +Audio +Video +Website +Location +Meeting +Calendar +Travel) that expand inline —
never a wizard, never a forced multi-step flow, so a bare task can be created in under 5 seconds.

---

## 7. Notifications

`expo-notifications` schedules on-device reminders (works fully offline — this is critical since
Gaurav may be somewhere with no signal when a P1 reminder needs to fire). Firebase Cloud
Messaging is layered on top for reminders that should also reach a second device (e.g. Abhay
wants to be pinged too) — this only requires the cloud sync to have happened first.

Reminder types wired in v1: due-today, overdue, meeting-15-min-before, travel-day-before,
P1-daily-digest. Reminder lead time is configurable per task and has a sensible global default in
Settings.

---

## 8. Third-Party APIs — identified for later phases

| Feature | API | Notes |
|---|---|---|
| Google Sign-In | Supabase Auth + Google OAuth | Needs a Google Cloud OAuth client ID (free). |
| Apple Sign-In | Supabase Auth + Sign in with Apple | Required by Apple if any other social login is offered on iOS; needs an Apple Developer account ($99/yr). |
| Maps (v1.1 richer picker) | Google Maps SDK / Places Autocomplete | Needs a Google Maps API key with billing enabled (has a generous free tier). v1 avoids this cost by deep-linking to the Maps app instead. |
| Google Calendar sync | Google Calendar API v3 | OAuth scope `calendar.events`; needed only when we go beyond "add to whatever calendar app is on the phone." |
| Apple Calendar sync | EventKit (native, via `device_calendar` plugin) | No API key needed — it's an on-device permission. |
| Push notifications | Firebase Cloud Messaging | Free; APNs certificate needed for iOS (via Apple Developer account). |
| WhatsApp | `url_launcher` with `wa.me` deep link | No official API needed for "open a chat" in v1; WhatsApp Business API is a paid v2 option if automated sending is ever wanted. |
| Speech-to-text (future AI) | On-device: `speech_to_text` plugin. Cloud option: OpenAI Whisper API or Google Speech-to-Text | For "Voice → Text → Translate" (Req. #11/#42). |
| Translation (EN/HI) | Google Cloud Translation API, or on-device ML Kit Translate | ML Kit works offline once language packs are downloaded — a good fit for the offline-first philosophy. |

None of these are required to ship v1's core task-management functionality; they are called out
so the schema and plugin choices already accommodate them without rework.

---

## 9. Security Notes

- Supabase Auth issues short-lived JWTs; the app never stores the password, only the session
  token, kept in `expo-secure-store` (iOS Keychain / Android Keystore), not plain AsyncStorage.
- Attachments are private by default (§5.4); signed URLs expire in 60 minutes.
- RLS is enabled on every cloud table — a compromised anon key alone cannot read another
  workspace's data.

---

## 10. Phased Delivery Plan

**Phase 1 (this build)** — local SQLite database fully implemented for all tables above; core
screens (Home/Today, Tasks list, New Task, Task Detail, Edit, Reassign, Remarks timeline,
Contacts, basic Calendar/Travel list views, Search, Filters); demo seed data; Supabase SQL schema
file ready to run once a project exists; sync engine scaffolded with clear interfaces (queue
read/write, retry policy) but the actual Supabase upload calls are stubbed behind a
`SyncService` interface so Phase 2 is "implement 4 methods against a real project," not "redesign
the app."

**Phase 2** — wire `SyncService` to a real Supabase project (you create the project; 10-minute
setup documented in `SUPABASE_SETUP.md`), attachments (camera/gallery/PDF/audio
record-playback/video), email/contact quick-actions (call/WhatsApp/save/copy), maps deep-links,
meeting links, calendar-add-event, sharing.

**Phase 3** — push notifications end-to-end, travel workflow polish, Google/Apple calendar API
integration, Google/Apple sign-in.

**Phase 4** — AI features (voice-to-task, transcription, translation, AI-suggested priority,
daily digest, meeting-notes summarization).

This document will be updated as each phase ships.
