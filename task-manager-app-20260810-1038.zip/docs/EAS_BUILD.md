# Building a standalone app (App Store / Play Store)

You don't need this for daily use — Expo Go (see the main README) is enough
for Gaurav to use the app every day, including on-device notifications,
camera, audio, and calendar access. Build a standalone app only when you want
to install it without Expo Go, distribute it to someone else, or submit it to
an app store. This cannot be done from this sandbox (it requires your own
Expo/Apple/Google accounts and, for iOS, either a Mac or Expo's cloud build
service), so treat this file as a walkthrough for you to run yourself.

## 1. One-time account setup

- Free **Expo account** at https://expo.dev — needed either way.
- **Google Play Console** account ($25 one-time) — only if publishing to Android.
- **Apple Developer Program** account ($99/year) — only if publishing to iOS or using push notifications/Sign in with Apple in a standalone build.

## 2. Install the EAS CLI and log in

```bash
cd app
npm install -g eas-cli
eas login
eas build:configure
```

This creates an `eas.json` with `development`, `preview`, and `production`
profiles.

## 3. Android — build an installable APK (no Play Store needed)

Good for handing Gaurav a file to install directly:

```bash
eas build --platform android --profile preview
```

EAS builds it on Expo's servers (free tier available) and gives you a
download link for a `.apk`. Send it to the phone and open it — Android will
ask to allow installs from that source once.

## 4. Android — Play Store release

```bash
eas build --platform android --profile production
eas submit --platform android
```

`eas submit` uploads the resulting `.aab` to the Play Console. You'll need to
finish the store listing (screenshots, description, privacy policy URL —
required because this app requests camera/microphone/contacts/calendar
permissions) in the Play Console itself.

## 5. iOS — TestFlight or App Store

```bash
eas build --platform ios --profile production
eas submit --platform ios
```

The first run walks you through connecting your Apple Developer account and
generating signing credentials — EAS manages certificates and provisioning
profiles for you, so you don't need Xcode or a Mac even for iOS. After
`eas submit`, the build appears in App Store Connect; add it to a TestFlight
group to let Gaurav install it before it's public, or submit it for App
Store review.

## 6. Push notifications, Google/Apple Sign-In (if added later)

These require a standalone/development build rather than Expo Go once
enabled (Expo Go can't hold the native credentials they need). If you add
these in a future phase, re-run `eas build` — no other project changes are
needed since the code already targets Expo's config-plugin system.

## Before you submit to a store

- Update the placeholder app icon/splash in `app/assets/` — the defaults are
  Expo's own placeholder art.
- Fill in a real `bundleIdentifier` (iOS) / `package` (Android) in `app.json`
  under a domain you control, e.g. `com.redcliffelabs.taskmanager`.
- Double-check every permission description in `app.json` (`infoPlist` /
  `android.permissions`) accurately describes why the app needs it — both
  Apple and Google reviewers check this.
- Decide on a privacy policy URL (required by both stores given the
  camera/microphone/contacts/calendar permissions) and add it to `app.json`'s
  `ios.infoPlist` / the Play Console listing.
