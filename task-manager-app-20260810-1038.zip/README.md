# Gaurav's Task Manager

A task manager, meeting manager, follow-up tracker, travel planner, and
communication hub in one app — built for Gaurav, who manages Abhay Singavi's
calendar, meetings, follow-ups, travel, and personal tasks day to day.

Full design rationale, data model, and sync architecture: **[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)**.

## What this is

- **React Native + Expo**, TypeScript, one codebase for iOS, Android, and web.
- **Offline-first**: every read/write hits local SQLite instantly; nothing
  waits on the network. Works fully with zero setup — no account, no
  internet required.
- **Optional cloud sync**: connect a free Supabase project to sync across
  devices (see [docs/SUPABASE_SETUP.md](docs/SUPABASE_SETUP.md)) — entirely
  opt-in, skippable from inside the app.
- **Demo data included**: the app seeds realistic example tasks (a payment
  follow-up, a Mumbai travel plan, a reassignment, an overdue item, etc.) the
  first time it runs, so there's something to explore immediately.

## Run it on your phone (fastest path — no SDKs to install)

You only need [Node.js](https://nodejs.org) (LTS) installed on your computer.
Nothing else — not Xcode, not Android Studio.

```bash
cd app
npm install
npx expo start
```

This prints a QR code in your terminal.

- **On iPhone**: install the free **Expo Go** app from the App Store, then
  scan the QR code with your Camera app (it'll prompt to open in Expo Go).
- **On Android**: install the free **Expo Go** app from the Play Store, then
  use Expo Go's built-in "Scan QR code" button.

The app opens in seconds. Any code changes you make save and reload instantly
on the phone (no rebuild). Your phone and computer need to be on the **same
Wi-Fi network** for this. If they can't be (e.g. corporate Wi-Fi blocks it),
run `npx expo start --tunnel` instead — slower, but works over any network.

### First-run checklist once it opens

1. You'll land on **Home** with demo tasks already loaded.
2. Tap the **+ NEW TASK** button (bottom right, always visible) — create a task in a few seconds.
3. Tap any task card to open its full detail screen — try **Edit**, **Reassign**, **Complete**, **Share**.
4. In a task, try **Attachments** — take a photo, record a voice note, attach a PDF.
5. Check the **Calendar** and **Travel** tabs — the demo data includes a Mumbai trip and today's meetings.
6. Tap the menu icon (top right, any tab) → **More** → **Categories** / **Sync Status**.

## Project structure

```
app/                      the Expo app (everything runnable lives here)
  App.tsx                 entry point: DB init, session, optional sign-in gate, navigation
  src/
    db/                   SQLite schema, repositories (one file per entity), live-query hook
    lib/                  cross-cutting helpers: actions (call/email/maps/share), notifications,
                           calendar integration, local file storage, Supabase client + sync engine
    store/                Zustand session store (local user/device identity)
    theme/                colors, spacing, typography — the whole app's design tokens in one file
    navigation/            bottom tabs + root stack
    components/            shared UI: task cards, badges, form fields, attachments UI
    screens/                one file per screen
docs/
  ARCHITECTURE.md         full system design — read this first for the "why"
  SUPABASE_SETUP.md        turning on optional cloud sync
  EAS_BUILD.md             building a standalone app (not required for daily use)
  supabase/schema.sql       the cloud database schema (run once in Supabase's SQL editor)
```

## What's implemented (v1 / Phase 1–2 of the architecture doc)

Dashboard with smart counts and Today view; categories (default 4 + custom);
P1/P2/P3 priority; full status set; assignment/reassignment with history;
remarks timeline; activity history log; edit-anything; search; filters;
contacts with call/WhatsApp/save/copy; email, website, and meeting links;
Google Maps deep links; add-to-device-calendar; travel plans with city
picker; image/PDF/audio/video attachments (camera, gallery, recording,
playback, rename, share, delete); local notifications/reminders; share task;
optional Supabase cloud sync with email/password sign-in.

## What's intentionally deferred (see ARCHITECTURE.md §10 for the full phased plan)

Google/Apple social sign-in, two-way Google/Apple Calendar API sync (v1 adds
events to whichever calendar app is already on the phone, one-way), push
notifications to a second device, and the AI features (voice-to-task,
transcription, translation, AI-suggested priority) — the data model already
has the fields these would need, so none of this requires a redesign later.

## A note on testing in this session

This project was built in a cloud sandbox with no Android emulator and no
Mac/iOS simulator available, so device testing could not be performed from
here. What **was** verified here: `tsc --noEmit` passes with zero errors, and
Metro successfully bundles the entire app for both the `android` and `ios`
platforms (1950+ modules, no unresolved imports). That's strong evidence the
code is structurally sound, but it is not the same as tapping through it on a
real phone — please run through the checklist above on your own device and
report back anything that looks or behaves wrong.
